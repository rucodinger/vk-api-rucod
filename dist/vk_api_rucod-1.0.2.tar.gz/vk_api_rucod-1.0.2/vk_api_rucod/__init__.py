"""vk-api-rucod is library with new functions for create vk bots"""

# Files import
from .VkApiFunctions import VkBot
