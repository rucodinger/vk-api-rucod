from setuptools import setup

setup(
    name='vk_api_rucod',
    version='1.0.2',
    packages=['vk_api_rucod'],
    author='RuCodinger',
    author_email='rucodinger@gmail.com',
    description='Library for create vk bots on Python',
    zip_safe=False
)
